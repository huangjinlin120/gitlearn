<?php
/**
 * Created by PhpStorm.
 * User: 刘海强
 * Date: 2018/11/9
 * Time: 13:50
 */

namespace app\yansuan\controller;

use think\Controller;
use think\Db;
use think\Request;

class Pc extends Common
{
    public function index(){
 
        $list = Db::name('userdata')->paginate(15);
        $this->assign('userlist', $list);
        return $this->fetch();
    }


    public function duizhao1(){
        if (Request::instance()->isPost()){
            $data = input('post.');
            $data['ctime'] = strtotime($data['ctime']);
            $data['recordertime'] = time();
            if (Db::table('userdata')->insert($data)){
                $this->success('添加对照组1成功','pc/index');
            }else{
                $this->error("添加对照组1失败");
            }
        }
        return $this->fetch();
    }



    public function duizhao2(){
        if (Request::instance()->isPost()){
            $data = input('post.');
            $data['recordertime'] = time();
            $data['ctime'] = strtotime($data['ctime']);
            if (Db::table('userdata')->insert($data)){
                $this->success('添加对照组2成功','pc/index');
            }else{
                $this->error("添加对照组2成功");
            }
        }
        return $this->fetch();
    }



    public function yanjiu(){
        if (Request::instance()->isPost()){
            $data1 = input('post.');
            $data1['recordertime'] = time();
            if(!empty($data1['one'])){
                $data2 = $data1['one'];
                unset($data1['one']);
            }

            $data1['ctime'] = strtotime($data1['ctime']);
            $id = Db::table('userdata')->insertGetId($data1);

            if (!empty($data2)){
                foreach ($data2 as $value){
                    $value['bind_user_id'] = $id;
                    Db::table('userdatashaicha')->insert($value);
                }
            }

            $this->success('添加研究成功','pc/index');

        }
        return $this->fetch();
    }

    public function del($id){
        if (Db::table('userdata')->where('id','=',$id)->delete()){
            $this->success("删除成功",'pc/index');
        }{
            $this->error("删除失败",'pc/index');
        }
    }

    public function edit(){

        if (Request::instance()->isPost()){
            $userdata = input('post.');

            Db::table('userdata')->where('id','=',$userdata['uid'])->strict(false)->update($userdata);



            //1.判断有没有流产信息
            if (!empty($userdata['one'])){



                Db::table('userdatashaicha')->where('bind_user_id','=',$userdata['uid'])->delete();
                $userdataliuchanlist = $userdata['one'];
                foreach ($userdataliuchanlist as $value){
                    $value['bind_user_id'] = $userdata['uid'];
                    Db::table('userdatashaicha')->insert($value);
                }
            }

            $this->success('修改成功');
        }

        $id = Request::instance()->param('id');
        //1.查看当前的类型
        $userdata = Db::table('userdata')->where('id','=',$id)->find();

        if ($userdata['type']==3){
            $userliuchanlist = Db::table('userdatashaicha')->where('bind_user_id','=',$id)->select();
            $this->assign('userliuchanlist',$userliuchanlist);
        }
        //2.赋值当前模板的数据
        $this->assign('userdata',$userdata);
        $userpage = Request::instance()->param('id');
        $this->assign('uid',$userpage);
        //2.选择适配的模板
        if ($userdata['type']==1){
            return $this->fetch('edit/duizhao1');
        }elseif ($userdata['type']==2){
            return $this->fetch('edit/duizhao2');
        }elseif ($userdata['type']==3){
            return $this->fetch('edit/yanjiu');
        }
    }
}