<?php
/**
 * Created by PhpStorm.
 * User: liu
 * Date: 2019/6/18
 * Time: 10:30
 */

namespace app\yansuan\controller;
use think\Controller;
use Wechat\WechatJS;

class Share extends Controller
{

    public function GetWechatJSAPI(){
        $API = new WechatJS();
        $API = $API->js('http://www.beijingtianxi.cn/yansuan/Login/index.html');
        return json($API);
    }

}