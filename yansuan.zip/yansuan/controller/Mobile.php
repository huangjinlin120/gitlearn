<?php
/**
 * Created by PhpStorm.
 * User: 刘海强
 * Date: 2018/11/9
 * Time: 13:50
 */

namespace app\yansuan\controller;

use think\Controller;


class Mobile extends Common
{
    public function Select(){
        return $this->fetch();
    }

    public function duizhao1(){
        return $this->fetch();
    }
    public function duizhao2(){
        return $this->fetch();
    }
    public function yanjiu(){
        return $this->fetch();
    }

}