<?php
/**
 * Created by PhpStorm.
 * User: 刘海强
 * Date: 2018/11/9
 * Time: 13:50
 */

namespace app\yansuan\controller;






use think\Controller;
use think\Request;
use think\Session;

class Login extends Controller
{
    public function check(){
        $name = Request::instance()->param('name');
        $pass = Request::instance()->param('pass');

        if ($name=='aa' and $pass=='aa'){
            //登陆成功
            Session::set('login','ok');
            if (ismobile()){
                return $this->redirect('Mobile/select',301);
            }else{
                return $this->redirect('Pc/index',301);
            }

        }else{
            //登陆失败 跳转到登陆页面
            return $this->error("登陆失败");
        }
    }

    public function index(){
        if (Request::instance()->isGet() and ismobile()){
            //手机
            return $this->fetch('m-login');
        }

        if (Request::instance()->isGet() and !ismobile()){
            //PC
            return $this->fetch('pc-login');
        }
    }
}