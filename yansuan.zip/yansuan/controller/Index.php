<?php
/**
 * Created by PhpStorm.
 * User: 刘海强
 * Date: 2018/11/9
 * Time: 13:50
 */

namespace app\yansuan\controller;






use think\Controller;
use think\Request;
use think\Session;

class Index extends Controller
{
    public function index(){
// 查询状态为1的用户数据 并且每页显示10条数据
        $list = Db::name('user')->where('status',1)->paginate(10);
// 把分页数据赋值给模板变量list
        $this->assign('list', $list);
// 渲染模板输出
        return $this->fetch();
        $this->redirect('Login/index');
    }

}


