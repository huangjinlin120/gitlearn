<?php
/**
 * Created by PhpStorm.
 * User: 刘海强
 * Date: 2018/11/9
 * Time: 13:50
 */

namespace app\yansuan\controller;

use think\Controller;
use think\Request;


class Mobile extends Common
{
    public function Select(){
        return $this->fetch();
    }

    public function duizhao1(){

        if (Request::instance()->isGet()){
            return $this->fetch();
        }


        if (Request::instance()->isPost()){
        }
    }
    public function duizhao2(){
        if (Request::instance()->isGet()){
            return $this->fetch();
        }


        if (Request::instance()->isPost()){
        }
    }
    public function yanjiu(){

        if (Request::instance()->isGet()){
            return $this->fetch();
        }


        if (Request::instance()->isPost()){
        }


        //return $this->fetch();
    }

}