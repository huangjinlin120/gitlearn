<?php
/**
 * Created by PhpStorm.
 * User: 刘海强
 * Date: 2018/11/9
 * Time: 13:50
 */

namespace app\yansuan\controller;

use think\Controller;
use think\Db;
use think\Request;

class Pc extends Common
{
    public function index(){
 
        $list = Db::name('userlist')->paginate(20);
        $this->assign('userlist', $list);
        return $this->fetch();
    }


    public function duizhao1(){
        if (Request::instance()->isPost()){

            //1.既往手术史
            $datas = input('post.');

            if (empty($datas['jiwangshoushushi'])){
                halt(123);
            }else{
                //1.转换成json数组
                $jiwangshoushushi = json($datas['jiwangshoushushi']);
            }


            //
        }

        return $this->fetch();
    }
    public function duizhao2(){
        if (Request::instance()->isPost()){
            halt(input('post.'));
        }
        return $this->fetch();
    }
    public function yanjiu(){
        return $this->fetch();
    }
}