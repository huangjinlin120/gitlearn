<?php
/**
 * Created by PhpStorm.
 * User: 刘海强
 * Date: 2018/11/9
 * Time: 13:50
 */

namespace app\yansuan\controller;






use think\Controller;
use think\Request;
use think\Session;

class Common extends Controller
{
    public function __construct(Request $request = null)
    {
        parent::__construct($request);

        //1.检查登陆
        $this->cklogin();
    }


    public function cklogin(){
        if (!Session::has('login')){
            $this->error("未登录",'Login/index');
        }
    }
}


