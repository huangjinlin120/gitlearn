//1.检测cookie有没有userinfo
if(!Cookies.get('token')){
// 	var loginUrl = window.location.href
// 	Cookies.set('loginUrl',loginUrl)
	window.location.href = 'http://www.beijingtianxi.cn/doctor/lhj/a/member/login.html'
	
	
// 	var begenurl = document.referrer;
// 	Cookies.set('begenurl',begenurl)
}




