<?php
/**
 * Created by PhpStorm.
 * User: liu
 * Date: 2019/6/14
 * Time: 14:01
 */


//HTTP协议

Request URL: https://unpkg.com/vue-lazyload@1.2.6/vue-lazyload.js
Request Method: GET
Status Code: 200  (from memory cache)
Remote Address: 104.16.125.175:443
Referrer Policy: no-referrer-when-downgrade


Accept: text/javascript, application/javascript, application/ecmascript, application/x-ecmascript, */*; q=0.01
Accept-Encoding: gzip, deflate, br
Accept-Language: zh-CN,zh;q=0.9
Connection: keep-alive
Cookie: BIDUPSID=090E0E10AD3A1CBACBADFD8C83F7A200; PSTM=1557053207; BD_UPN=12314753; BAIDUID=6745C086FE4D1E8ABA8D7FBCC6D8AAC1:FG=1; BDORZ=B490B5EBF6F3CD402E515D22BCDA1598; sug=3; sugstore=0; ORIGIN=2; bdime=0; MCITY=-%3A; H_PS_PSSID=26523_1433_21121_29135_29238_28519_29099_28836_29220; H_PS_645EC=6f611j0ppo0mFF2T038JKXTfceZTM8OW5xeySFAmdfy81dyNg2vAQNfcX5o; delPer=0; BD_CK_SAM=1; PSINO=2; BD_HOME=0
Host: www.baidu.com
Referer: https://www.baidu.com/
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.90 Safari/537.36
X-Requested-With: XMLHttpRequest