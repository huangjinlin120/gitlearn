if(localStorage.getItem('changgui')){
	location.href = "../../a/jzinfo/completed/comOver.html"
}