if (!Cookies.get('doctorname')) {
	var thisurl = window.location.href;
	console.log(this.thisurl)
	var doc = thisurl.split('/')

	Cookies.set('doctorname', doc[4])
}
