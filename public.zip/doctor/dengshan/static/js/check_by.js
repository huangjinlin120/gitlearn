if(localStorage.getItem('buyun')){
	location.href = "../../a/jzinfo/completed/cliOver.html"
}